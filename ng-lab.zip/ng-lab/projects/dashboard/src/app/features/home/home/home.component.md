# Home Component

Home page

[Lien](https://www.npmjs.com/package/webpack-bundle-analyzer)

```html
<app-home></app-home>
```
