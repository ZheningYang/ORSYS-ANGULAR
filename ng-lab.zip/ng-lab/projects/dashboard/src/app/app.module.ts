import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { CoreModule } from './core/core.module';
import { HomeModule } from './features/home/home.module';
import { CommentsModule } from './features/comments/comments.module';
import { AuthService } from './core/auth.service';
import { AUTH_SERVICE_TOKEN } from './core/app.guard';
import { environment } from '../environments/environment';
import { APPLICATION_ID } from './core/tokens';
import { ConnectorService } from './core/connector.service';
import { SearchService } from './core/search.service';
import { BrokerService } from './core/broker.service';

const AuthServiceFactory = (broker:BrokerService,connector:ConnectorService) => {
  return new AuthService(broker,connector);
};

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CoreModule,
    HomeModule,
    CommentsModule
  ],
  providers: [
    { provide: APPLICATION_ID, useValue:environment.APPLICATION_ID},
    { provide: AUTH_SERVICE_TOKEN, useFactory:AuthServiceFactory, deps: [BrokerService,ConnectorService] },
    { provide: APP_INITIALIZER, useValue: () => console.log("APP START"), multi:true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor() {
    //console.log(this);
  }
}
