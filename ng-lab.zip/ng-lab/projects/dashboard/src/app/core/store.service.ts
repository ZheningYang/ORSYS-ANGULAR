import { Injectable, Inject } from '@angular/core';
import { ActionTypes } from './action-types.enum';
import { BehaviorSubject } from 'rxjs';
import { BrokerService } from './broker.service';
import { AUTH_SERVICE_TOKEN } from './app.guard';
import { AuthService } from './auth.service';

export interface Action {
  type:ActionTypes,
  data?:any
}


@Injectable()
export class StoreService {


  state$ = new BehaviorSubject({})
  // Subject
  // ReplaySubject
  // BehaviorSubject

  history=[];

  constructor(
    private broker:BrokerService,
    @Inject(AUTH_SERVICE_TOKEN) private auth:AuthService
    ) {

    // console.log(auth)

    window['getHistory'] = () => {
      console.groupCollapsed('Application Actions History');
      console.table(this.history)
      console.groupEnd();
    }

  }

  dispatch(action:Action){
    this.history.push( { time:Date.now() , ...action});
    this.broker.pubsub.publish(action.type, action.data);

    switch (action.type) {
      case ActionTypes.AUTH:
        this.auth.connect(action.data).subscribe( res => this.state$.next({currentUser: res }) )
        break;
    }

    return this.state$;
  }
}
