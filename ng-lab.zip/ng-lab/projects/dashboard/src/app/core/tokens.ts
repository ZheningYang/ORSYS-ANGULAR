import { InjectionToken } from "@angular/core";

export const BASE_HREF = new InjectionToken('BASE_HREF');
export const APPLICATION_ID = new InjectionToken('APPLICATION_ID');

