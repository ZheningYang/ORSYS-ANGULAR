import { LkbUiFormatDirective } from './lkb-ui-format.directive';

describe('LkbUiFormatDirective', () => {
  it('should create an instance', () => {
    const directive = new LkbUiFormatDirective();
    expect(directive).toBeTruthy();
  });
});
