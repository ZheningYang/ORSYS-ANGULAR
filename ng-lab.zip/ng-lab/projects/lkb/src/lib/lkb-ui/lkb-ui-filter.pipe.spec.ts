import { LkbUiFilterPipe } from './lkb-ui-filter.pipe';

describe('LkbUiFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new LkbUiFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
