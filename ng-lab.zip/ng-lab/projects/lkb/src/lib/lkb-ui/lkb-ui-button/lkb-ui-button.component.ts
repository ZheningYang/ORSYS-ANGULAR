import { Component, OnInit, Input, SimpleChange, OnChanges, HostListener, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'lkb-ui-button',
  templateUrl: './lkb-ui-button.component.html',
  styleUrls: ['./lkb-ui-button.component.scss'],
  // encapsulation:ViewEncapsulation.None
})
export class LkbUiButtonComponent implements OnInit, OnChanges {

  @Input() level:LkbUiButtonLevels = LkbUiButtonLevels.PRIMARY

  @HostListener('window:keydown.SPACE', ['$event'] ) // host
  globalListener(event){
    // console.log('globalListener',event);
  }

  constructor() {
    // console.log('constructor','LkbUiButtonComponent')
  }

  ngOnChanges(changes:any) {
    // console.log('ngOnChanges','LkbUiButtonComponent')
  }

  ngOnInit() {
    // console.log('ngOnInit','LkbUiButtonComponent')
  }

  ngDoCheck() {
    // console.log('ngDoCheck','LkbUiButtonComponent')
  }

  ngOnDestroy() {
    // console.log('ngOnDestroy','LkbUiButtonComponent')
  }



}

export enum LkbUiButtonLevels {
    PRIMARY = 'PRIMARY',
    OPTIONAL = 'OPTIONAL',
    CRITICAL = 'CRITICAL'
}
