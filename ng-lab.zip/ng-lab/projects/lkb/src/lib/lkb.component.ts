import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lkb-lkb',
  template: `
    <p>
      lkb works!
    </p>
  `,
  styles: []
})
export class LkbComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
