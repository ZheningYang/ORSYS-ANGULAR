import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lkb-view-list',
  templateUrl: './lkb-view-list.component.html',
  styleUrls: ['./lkb-view-list.component.scss']
})
export class LkbViewListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
