import { Component } from '@angular/core';
import { LkbUiButtonLevels } from 'projects/lkb/src/public-api';

import {of, Subscription, Observable, from, fromEvent} from 'rxjs'
import {map,tap, switchMap} from 'rxjs/operators'
import { fromArray } from 'rxjs/internal/observable/fromArray';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  levels = LkbUiButtonLevels

  data$ = from( fetch('https://www.reddit.com/r/angular/.json').then(res => res.json()))

  source$ = fromEvent(window, 'click')
    .pipe(
      tap(console.log),
      switchMap(() => this.data$)
      /* map( data => data+'**' ),
      tap( console.log ) */
      );

  //val1:any;
  val2:any;
  //sub1$:Subscription;
  sub2$:Subscription;

  log(evt){

    console.time('Click')
    console.groupCollapsed('Log Method')
      console.warn(evt)
      console.table(this.levels)
    console.groupEnd()
    console.timeEnd('Click')

  }

  constructor(){
    //this.sub1$ = this.source$.subscribe( data => this.val1=data)
  }

  ngOnInit(){
    this.sub2$ = this.source$/* .pipe() */.subscribe( data => this.val2=data)
  }

  ngOnDestroy(){
    //this.sub1$.unsubscribe()
    this.sub2$.unsubscribe()
  }


}
